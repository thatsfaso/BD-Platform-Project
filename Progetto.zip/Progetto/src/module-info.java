/**
 * 
 */
/**
 * @author ilianofasolino
 *
 */
module Progetto {
	requires java.sql;
}